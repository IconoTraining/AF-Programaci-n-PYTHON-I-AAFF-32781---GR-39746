# Primera forma importamos el modulo entero
import persona

# Sintaxis: modulo.recurso
luis = persona.Persona("Luis",45)
luis.mostrarInfo()


# Segunda forma importar la clase Persona del modulo persona
from persona import Persona
marta = Persona("Marta",18)
marta.mostrarInfo()


# Tercera forma importar la clase Persona del modulo persona con alias
from persona import Persona as Person
jorge = Person("Jorge", 32)
jorge.mostrarInfo()