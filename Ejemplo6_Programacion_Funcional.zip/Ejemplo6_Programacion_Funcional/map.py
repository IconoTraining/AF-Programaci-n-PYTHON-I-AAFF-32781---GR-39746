# la funcion map, se aplica sobre una coleccion donde
# con cada elemento se invoca a una funcion que modifica el elemento
# o devuelve uno nuevo.
# Importante que la funcion retorne un elemento
# sintaxis: map(funcion, coleccion)

# Ejemplo 1
numeros = [3,8,4,15,30]

def duplicar(numero):
    return numero * 2

numerosDobles = list(map(duplicar, numeros))
print(numerosDobles)
print(numeros)

# Ejemplo 2
alumnos = dict(Luis=8.9, Maria=6.3, Adolfo=6.9)

def sumarPunto(item):
    return item[0], item[1] + 1

nuevasNotas = dict(map(sumarPunto, alumnos.items()))
print(nuevasNotas)


# Ejemplo 3
class Persona:   
    def __init__(self, nombre, edad) -> None:
        self.nombre = nombre
        self.edad = edad
    
    def mostrarInfo(self):
        print("Hola, me llamo {} y tengo {} años".format(self.nombre, self.edad))
        
personas = [Persona("Juan",27), Persona("Maria", 19), Persona("Pedro", 22)]

def modificarPersona(persona):
    persona.nombre = persona.nombre.upper()
    persona.edad += 1
    return persona

personas = list(map(modificarPersona, personas))

for person in personas:
    person.mostrarInfo()