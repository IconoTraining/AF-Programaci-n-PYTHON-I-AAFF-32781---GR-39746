# abrir el fichero en modo lectura
fichero = open("Ejemplo8_Ficheros_Texto/fichero.txt", "rt", encoding="utf-8")

# leer todo el contenido
texto = fichero.read()
print(texto)

# mover el puntero al primer caracter
fichero.seek(0)

# leer los primeros 5 caracteres de la primera linea
linea = fichero.readline(5)
print(linea)

# leer todo el contenido y procesar linea a linea
fichero.seek(0)
lineas = fichero.readlines()
for linea in lineas:
    print(linea, end="")
print()

# crear una lista con el contenido del fichero
fichero.seek(0)
lista = list(fichero)
print(lista)
for linea in lista:
    print(linea, end="")
print()

# cerrar el fichero
fichero.close()