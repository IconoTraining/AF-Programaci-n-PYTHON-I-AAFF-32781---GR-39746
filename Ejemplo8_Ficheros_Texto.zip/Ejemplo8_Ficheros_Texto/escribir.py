# abrir el fichero en modo escritura
fichero = open("Ejemplo8_Ficheros_Texto/fichero_write.txt", "wt", encoding="utf-8")

# Agregar texto al fichero hasta que el usuario FIN
texto = ""
while (texto != "FIN"):
    texto = input("Introduce texto a guardar, (FIN) para terminar: ")
    if (texto == "FIN"):
        break
    fichero.write(texto)
    fichero.write("\n")
    
# cerrar el fichero
fichero.close()