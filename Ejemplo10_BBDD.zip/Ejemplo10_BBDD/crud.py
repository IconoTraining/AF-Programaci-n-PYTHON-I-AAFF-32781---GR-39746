# CRUD
# C -> Create -> Insert
# R -> Read -> Select
# U -> Update -> Update
# D -> Delete -> Delete

from ast import arg
import sqlite3

# Abrir una conexion
conexion = sqlite3.connect("Ejemplo10_BBDD/tienda.db")

# Obtener un cursor
cursor = conexion.cursor()

''' ************** Insertar datos ************** '''
# Insertar un registro
#cursor.execute("insert into PRODUCTOS values (1, 'Pantalla 17 pulgadas', 89.95)")

# Insertar varios registros con una lista
lista = [(2,'Teclado', 29.50),(3, 'Raton', 15.0),(4, 'Impresora', 120.80)]
sql = "insert into PRODUCTOS values (?,?,?)"
#cursor.executemany(sql, lista)

# IMPORTANTE EL COMMIT
conexion.commit()

''' ************** Consultar datos ************** '''
# consultar todos los productos
cursor.execute("select * from PRODUCTOS")
productos = cursor.fetchall() # recoge todos los resultados obtenidos
for prod in productos:
    print(prod)
print("------ FIN ------")

# consultar todos los productos con precio inferior a 50€
cursor.execute("select * from PRODUCTOS where precio < 50")
productos = cursor.fetchall() # recoge todos los resultados obtenidos
for prod in productos:
    print(prod)
print("------ FIN ------")

# consultar todos los productos ordenados por descripcion asc y desc
cursor.execute("select * from PRODUCTOS order by descripcion desc")
productos = cursor.fetchall() # recoge todos los resultados obtenidos
for prod in productos:
    print(prod)
print("------ FIN ------")

# mostrar los productos cuya descripcion comience por R
cursor.execute("select * from PRODUCTOS where descripcion LIKE 'R%' ")
productos = cursor.fetchall() # recoge todos los resultados obtenidos
for prod in productos:
    print(prod)
print("------ FIN ------")

''' ************** Modificar datos ************** '''
# Modificar el precio de la impresora
cursor.execute('update PRODUCTOS SET precio=140.00 where descripcion = "Impresora" ')
query = 'update PRODUCTOS SET precio=? where descripcion = ? '
datos = (40, "Teclado" ) # tupla con los parametros
cursor.execute(query, datos)
conexion.commit()

''' ************** Eliminar datos ************** '''
# Eliminar el raton
query = "delete from PRODUCTOS where descripcion= ? "
dato = ("Raton", )  # Hay que engañarle para que sea una tupla
cursor.execute(query, dato)

# Tambien funciona:
#dato = "Raton"
#cursor.execute(query, (dato, ))

conexion.commit()