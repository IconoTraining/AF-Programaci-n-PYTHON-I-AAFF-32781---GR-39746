# CRUD
# C -> Create -> Insert
# R -> Read -> Select
# U -> Update -> Update
# D -> Delete -> Delete

import sqlite3

# Abrir una conexion
conexion = sqlite3.connect("Ejemplo10_BBDD/tienda.db")

# Obtener un cursor
cursor = conexion.cursor()

''' ************** Insertar datos ************** '''
# Insertar un registro
#cursor.execute("insert into PRODUCTOS values (1, 'Pantalla 17 pulgadas', 89.95)")

# Insertar varios registros con una lista
lista = [(2,'Teclado', 29.50),(3, 'Raton', 15.0),(4, 'Impresora', 120.80)]
sql = "insert into PRODUCTOS values (?,?,?)"
#cursor.executemany(sql, lista)

# IMPORTANTE EL COMMIT
conexion.commit()

''' ************** Consultar datos ************** '''
# consultar todos los productos
cursor.execute("select * from PRODUCTOS")
productos = cursor.fetchall() # recoge todos los resultados obtenidos
for prod in productos:
    print(prod)
print("------ FIN ------")

# consultar todos los productos con precio inferior a 50€
cursor.execute("select * from PRODUCTOS where precio < 50")
productos = cursor.fetchall() # recoge todos los resultados obtenidos
for prod in productos:
    print(prod)
print("------ FIN ------")