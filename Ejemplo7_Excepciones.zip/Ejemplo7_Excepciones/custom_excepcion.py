''' Crear una excepcion personalizada  '''
class NegativoError(Exception):
    def __init__(self, message):
        self.message = message
        #super().__init__(self.message)
        
    def getMessage(self):
        return self.message
 
try:       
    edad = int(input("Introduce tu edad: "))
    if edad < 0:
        # lanzar la excepcion
        raise NegativoError("No puede ser negativa la edad")
except NegativoError as error:
    print(error.getMessage())