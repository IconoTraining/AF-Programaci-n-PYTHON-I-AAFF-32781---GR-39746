# sumar los numeros
import traceback

datos = ['1','2','3','4','5']
suma = 0

for i in range(len(datos) + 1):
    try:
        # acceder al dato
        dato = datos[i]
        
        # lo convertimos en numero
        numero = int(dato)
        
    except (ValueError, IndexError, Exception) as ex:
        print("Error de tipo", type(ex))
        print("Ha ocurrido un error", ex) #mensaje
        traceback.print_exc() # stack trace
        
    else:
        # sumamos el numero
        suma += numero

print("Suma:", suma)