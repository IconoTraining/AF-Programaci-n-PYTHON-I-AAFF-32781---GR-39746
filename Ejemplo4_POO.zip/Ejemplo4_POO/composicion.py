class Direccion:
    
    def __init__(self, calle: str, numero:int, poblacion:str) -> None:
        self.calle = calle
        self.numero = numero
        self.poblacion = poblacion
        
    def mostrar(self):
        # Mayor, 5 - Madrid
        return self.calle + ", " + str(self.numero) + " - " + self.poblacion
        

class Persona:
    
    def __init__(self, nombre: str, edad: int, direccion: Direccion) -> None:
        self.nombre = nombre
        self.edad = edad
        self.direccion = direccion
    
    def mostrarInfo(self):
        print("Hola, me llamo {}, tengo {} años y vivo en {}".format(self.nombre, self.edad, self.direccion.mostrar()))
    
   
# Crear la direccion de Juan
dirJuan = Direccion("Mayor", 5 , "Madrid")

# Crear objetos de Persona
juan = Persona("Juan", 27, dirJuan)
maria = Persona("Maria", 35, Direccion("Diagonal", 150, "Barcelona"))

# Invocar a los recursos de un objeto
juan.mostrarInfo()
maria.mostrarInfo()

# los atributos o propiedades son publicas
juan.direccion.numero = 35
juan.mostrarInfo()