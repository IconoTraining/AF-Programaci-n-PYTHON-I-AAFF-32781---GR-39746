class Persona:
    
    def __init__(self, nombre, edad) -> None:
        self.nombre = nombre
        self.edad = edad
    
    def mostrarInfo(self):
        return("Hola, me llamo {} y tengo {} años".format(self.nombre, self.edad))


class Empleado(Persona):
    
    def __init__(self, nombre, edad, sueldo) -> None:
        super().__init__(nombre, edad)
        self.sueldo = sueldo  
        
    def mostrar(self):
        return super().mostrarInfo() + ", sueldo " + str(self.sueldo)
        
                    

# Crear objetos de Empleado
juan = Empleado("Juan", 27, 37000)
maria = Empleado("Maria", 35, 45000)

# Invocar a los recursos de un objeto
print(juan.mostrar())
print(maria.mostrar())

# los atributos o propiedades son publicas
juan.edad += 1
juan.sueldo = 43000
print(juan.mostrar())