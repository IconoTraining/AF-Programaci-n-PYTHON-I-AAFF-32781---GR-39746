'''
    Una clase encapsulada tiene todas sus propiedades declaradas
    como privadas y se accede a ellas solo a través de kis metodos
    get y set publicos
'''

class Fecha:
      
    def __init__(self, dia, mes, anyo) -> None:
        self.setDia(dia)
        self.setMes(mes)
        self.setAnyo(anyo)
    
    def getDia(self):
        return self.__dia
    
    def setDia(self, dia):
        # los dias son validos entre 1 y 31
        if dia > 0 and dia <= 31:
            self.__dia = dia 
        else:
            print("Dia no valido")
            self.__dia = 0
            
    def getMes(self):
        return self.__mes
    
    def setMes(self, mes):
        # los meses son validos entre 1 y 12
        if mes > 0 and mes <= 12:
            self.__mes = mes 
        else:
            print("Mes no valido")
            self.__mes = 0
            
    def getAnyo(self):
        return self.__anyo
    
    def setAnyo(self, anyo):
        # los meses son validos entre 2022 y 2023
        if anyo == 2022 or anyo == 2023:
            self.__anyo = anyo 
        else:
            print("Anyo no valido")
            self.__anyo = 0
            
    def mostrar(self):
        print(self.__dia, self.__mes, self.__anyo, sep="/")
            
            
# Crear fechas
hoy = Fecha(18,10,2022)
hoy.mostrar()

erronea = Fecha(8766, 75, -45)
erronea.mostrar()