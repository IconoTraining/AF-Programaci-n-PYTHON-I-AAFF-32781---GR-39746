texto = "bienvenidos al curso de Python"
print(texto)

print(texto.capitalize())
print(texto.upper())
print(texto.lower())
print(texto.swapcase())

print(texto.isalnum())   # False por los espacios en blanco
print("Pepito".isalnum())
print("12345".isalnum())

print(texto.isalpha())   # False por los espacios en blanco
print("Pepito".isalpha())
print("12345".isalpha())

print(texto.isdigit())   # False por caracteres de texto
print("Pepito".isdigit())
print("12345".isdigit())

print("Mayusculas?", texto.isupper())
print("Minusculas?", texto.islower())

ejemplo = "      lunes       "
print(ejemplo, end=".\n")
print(ejemplo.lstrip(), end=".\n")
print(ejemplo.rstrip(), end=".\n")
print(ejemplo.strip(), end=".\n")


print("12345".zfill(8)) # rellena 0 por delante hasta obtener los 8 caracteres
print(ejemplo.ljust(20, 'E')) # Añade E al final hasta completar los 20 caracteres
print(ejemplo.rjust(20, 'E')) # Añade E al principio hasta completar los 20 caracteres

print("Longitud:", len(texto))
print("Longitud:", texto.__len__())

print("Max:", max(texto))
print("Min:", min(texto))

print(texto.replace('e','E'))  # Cambia todas

palabras = texto.split()
print(palabras)
print("-".join(palabras))

fecha="17/10/2022"
datos = fecha.split("/")
print(len(datos))
print("Dia:", datos[0])
print("Mes:", datos[1])
print("Año:", datos[2])