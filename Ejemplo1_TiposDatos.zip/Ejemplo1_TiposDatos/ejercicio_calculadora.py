'''
    Solicitar al usuario 2 numeros
    Mostrar suma, resta, multiplicacion, division entera, modulo y potencia
'''

numero1 = int(input("Introduce un numero: "))
numero2 = int(input("Introduce otro numero: "))

print("Suma:", numero1 + numero2)
print("Resta:", numero1 - numero2)
print("Multiplicacion:", numero1 * numero2)
print("Division entera:", numero1 // numero2)
print("Resto:", numero1 % numero2)
print("Potencia:", numero1 ** numero2)