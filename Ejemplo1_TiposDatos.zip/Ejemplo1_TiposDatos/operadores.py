# Operadores aritmeticos (+,-,*,/,%,**,//)
numero1 = 7
numero2 = 5
print("Division:", 7/5)
print("Division entera:", 7//5)
print("Resto:", 7%5)
print("Potencia:", 7**5)

# Operadores asignacion (+=,-=,*=,/=,%=,**=,//=)
# numero1 = numero1 + 3
numero1 += 3

# En python no existe incrementos, ni decrementos 
numero1 += 1     # numero1++
numero1 -= 1     # numero1--

# Operadores de comparacion (<,>,<=, >=, ==, !=)
print("Numero 1 Menor:", numero1 < numero2)
nombre1="Juan"
nombre2="Juan"
print("Son iguales?", nombre1 == nombre2)

# Operadores logicos (and, or, not)
print("and:", (numero1==10 and nombre1=="Juan"))
print("or:", (numero1==1111 or nombre1=="Juan"))
print("not:", not(numero1==1111))

# Operadores de identidad (is, is not)
num1 = 6
num2 = 6
print("Es el mismo contenido", num1 is num2) # True

nombres1 = ['Juan', 'Maria']
nombres2 = ['Juan', 'Maria']
print("Es el mismo contenido", nombres1 is nombres2) # False porque las direcciones de memoria son diferentes
print("Es diferente contenido", nombres1 is not nombres2)

# Operadores de pertenencia (in, not in)
print('Luis' in nombres1)
print('Maria' in nombres1)
print('Luis' not in nombres1)