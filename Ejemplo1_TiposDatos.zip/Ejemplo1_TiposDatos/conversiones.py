import math

# convertir de texto a numero entero
dato = input("Introduce un numero: ")
print(type(dato)) #str
numero1 = int(dato)

numero2 = int(input("Introduce otro numero: "))
print("Suma:", numero1+numero2)


# convertir de texto a numero real
radio = float(input("Introduce el radio de un circulo: "))
print("Area del circulo:", math.pi*radio**2) # ** operador potencias
# round(que, num_decimales)
print("Area del circulo:", round(math.pi*radio**2, 2))
 
# convertir de numero a texto
texto = str(numero1)
texto = str(radio)