def datosTrabajador(nombre, estadoCivil="Soltero",  sueldo=24000):
    print(nombre, "esta", estadoCivil, "y gana", sueldo)

# No interpreta que 43000 es el sueldo    
# datosTrabajador("Juan", 43000)
# solucion:
datosTrabajador("Juan", sueldo = 43000)
datosTrabajador("Maria")
datosTrabajador("Pedro", "Casado")


def concatenar(*datos, separador=" | "):
    return separador.join(datos)

print(concatenar('lunes','martes','miercoles','jueves','viernes','sabado','domingo'))
print(concatenar('lunes','martes','miercoles','jueves','viernes','sabado','domingo', separador="-"))