# Funcion con numero variable de argumentos
def sumar(*numeros):
    suma = 0
    for num in numeros:
        suma += num
    return suma

print(sumar())
print(sumar(7))
print(sumar(7,2))
print(sumar(2,5,3))
print(sumar(1,9,2,8))


# crear una funcion que recibe el nombre y las notas de una lumno
# utilizando la funcion sumar() calcular la nota media
# devolver el nombre en mayusculas y la nota_media
def procesarNotas(nombre, *notas):
    notaMedia = sumar(*notas) / len(notas)
    return nombre.upper(), notaMedia

print(procesarNotas("Juan", 2,5,3))
print(procesarNotas("Maria", 9,8))
print(procesarNotas("Pedro", 7,5,9,8))