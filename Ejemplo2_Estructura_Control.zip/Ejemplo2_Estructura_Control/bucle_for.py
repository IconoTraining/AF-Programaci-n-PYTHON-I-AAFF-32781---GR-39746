nombres = ['Luis', 'Jorge', 'Maria', 'Laura', 'Pedro']

for item in nombres :
    print(item)
print("------ FIN ------")

''' rangos '''
# Mostrar los numeros del 0 al 9
for numero in range(10):  # Rango va desde 0 a numero-1
    print(numero)
print("------ FIN ------")

# Mostrar los numeros del 1 al 10
for numero in range(1,11):  # Rango va desde 1 a numero-1
    print(numero)
print("------ FIN ------")

# Mostrar los numeros del 0 al 10 de 2 en 2
for numero in range(0,11, 2): 
    print(numero)
print("------ FIN ------")

# Mostrar los numeros del 10 al 1 en decreciente
for numero in range(10, 0, -1):
    print(numero)
print("------ FIN ------")

# Mostrar los nombres por posicion
for i in range(len(nombres)): # rango 0-4
    print(nombres[i])
print("------ FIN ------")