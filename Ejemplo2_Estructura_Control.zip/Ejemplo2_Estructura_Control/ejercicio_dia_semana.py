'''
    El usuario introduce una letra (l,m,x,j,v,s,d) y decimos a que dia de la semana corresponde.
    Puede ser minuscula o mayuscula.
    Ideas: or, upper(), lower()
'''
letra = input("Introduce letra del dia de la semana: ")

if letra == 'l' or letra == 'L':
    print("Es lunes")
elif letra.upper() == 'M':
    print("Es martes")
elif letra.lower() == 'x':
    print("Es miercoles")
elif letra.upper() == 'J':
    print("Es jueves")
elif letra.lower() == 'v':
    print("Es viernes")
elif letra.upper() == 'S':
    print("Es sabado")
elif letra.lower() == 'd':
    print("Es domingo")
else:
    print("Dia desconocido")