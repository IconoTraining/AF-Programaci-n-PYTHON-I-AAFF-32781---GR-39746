# listas: colecciones ordenadas de elementos
# en todas las colecciones los elementos pueden ser de diferentes tipos
# permiten elemento duplicados
# son mutables, permiten modificaciones
# Se crean con []

colores = ['rojo','verde','azul']
print(type(colores)) # list

# Mostrar la lista
print(colores)

# ordenar la lista
print(sorted(colores))  # ascendente
print(sorted(colores, reverse=True)) # descendente

# mostrar el color verde, posicion 1
print(colores[1])

# borrar el color azul, posicion 2
del colores[2]  # borrar por posicion
print(colores)

# concatenar a otra lista
masColores = ['blanco', 'negro', 'rosa', 'azul']
nuevaLista = colores + masColores
print(nuevaLista)

# borrar el color rosa
nuevaLista.remove('rosa') # borrar por elemento, solo el primero encontrado
print(nuevaLista)

# otra forma de borrar por posicion o por indice
nuevaLista.__delitem__(4)
print(nuevaLista)

# Añadir un elemento al final
nuevaLista.append('naranja')
print(nuevaLista)

# Insertar un elemento en la posicion
nuevaLista.insert(0, 'marron')
print(nuevaLista)

# Como podemos tener elementos duplicados
# Contar cuantos color verde tengo
print(nuevaLista.count('verde'))

# Mostrar el indice donde esta el color verde
print(nuevaLista.index('verde'))

# longitud de la lista
print(len(nuevaLista))
print(nuevaLista.__len__())

# Mostrar el ultimo elemento
print(nuevaLista[len(nuevaLista) - 1])
print(nuevaLista[- 1])

# Mostrar el tercer elemento empezando por el final
print(nuevaLista[- 3])

# Mostrar los 3 ultimos 
print(nuevaLista[-3:])

# Mostrar los 3 primeros 
print(nuevaLista[:3])

# Mostrar todos
print(nuevaLista[:])

# Mostrar desde posicion 2 a 4, el ultimo queda excluido
print(nuevaLista[2:4])

# Mostrar desde posicion -4 a -2, el ultimo queda excluido
print(nuevaLista[-4:-2])

# Siempre se recorre de izquierda a derecha.
print(nuevaLista[-2:-4])  # No funciona, devuelve la lista vacia

# Insertar un elemento en la posicion
datos = ['marron','amarillo','gris']
for i in range(len(datos)):     
    nuevaLista.insert(i, datos[i] )
print(nuevaLista)

# borrar todos los elementos de la lista
nuevaLista.clear()
print(nuevaLista)