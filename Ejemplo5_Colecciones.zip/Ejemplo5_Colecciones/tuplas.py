# tuplas: colecciones ordenadas pero inmutables
# se permiten elementos duplicados
# se crean con ()
# Ejemplos: dias de la semana, meses del año, estado civil, ...etc

dias = ('lunes','martes','miercoles','jueves','viernes','sabado','domingo')
print(type(dias))   # tuple 

# mostrar todos los dias
print(dias) 

# Recorrer una tupla
for dia in dias:
    print(dia)
    
# Mostrar el miercoles
print(dias[2])

# Intentamos borrar el lunes
# TypeError: 'tuple' object doesn't support item deletion
# del dias[0] 

# Intentamos modificar elementos
# TypeError: 'tuple' object does not support item assignment
# dias[0] = 'domingo'

# Concatenar tuplas
numeros = (1,2,3,4,5)
otra_tupla = dias + numeros
print(otra_tupla)

# Para concatenar ha detener mas de un elemento la tuple
masDias = ('sabado', 'domingo')
otra_tupla = dias + masDias
print(otra_tupla)

# Cuantos sabados hay?
print(otra_tupla.count('sabado'))

# En que posicion esta el viernes?
print(otra_tupla.index('viernes'))

# longitud
print(len(otra_tupla))
print(otra_tupla.__len__())

