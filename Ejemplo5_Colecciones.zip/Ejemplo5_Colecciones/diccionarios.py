# diccionarios: los elementos son key:value
# las claves no se pueden repetir pero los value si
# se crean con {}

# Si repito una clave se sobreescribe el valor
alumnos = {"Juan":6.4, "Maria":8.3, "Luis":6.4, "Adolfo":7.1, "Maria":9.3}
print(type(alumnos)) #dict

# Mostrar todos los alumnos
print(alumnos)

# Mostrar solo el nombre de los alumnos - keys
print(alumnos.keys())

# Mostrar solo las notas de los alumnos - values
print(alumnos.values())

# Mostrar si Maria esta en el diccionario
print("Maria" in alumnos)

# Acceder a los alementos por su clave
print(alumnos['Luis'])
print(alumnos.get('Luis'))

# Eliminar a Adolfo
del alumnos['Adolfo']
print(alumnos)

# Agregar a Pedro
alumnos['Pedro'] = 4.7
print(alumnos)

# Recorrer un diccionario
for alum in alumnos:  # solo me devulve las keys
    print(alum, alumnos[alum])
    
for item in alumnos.items():   # cada item es una tupla
    print(item)
    
for clave, valor in alumnos.items():
    print(clave, valor)
    
    
# Otras formas de crear diccionarios
otro = dict([("Luis",8.9), ("Maria",6.3), ("Adolfo", 6.9)])
otroMas = dict(Luis=8.9, Maria=6.3, Adolfo=6.9)

print(otro)
print(otroMas)