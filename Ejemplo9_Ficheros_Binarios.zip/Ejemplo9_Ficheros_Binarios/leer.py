import pickle

# Abrir el fichero en modo binario y lectura
fichero = open("Ejemplo9_Ficheros_Binarios/fichero.pckl", "rb")

# Recuperar el contenido
nombres = pickle.load(fichero)

# Mostrar el contenido y el tipo
print(nombres)
print(type(nombres))

# Cerrar el fichero
fichero.close()